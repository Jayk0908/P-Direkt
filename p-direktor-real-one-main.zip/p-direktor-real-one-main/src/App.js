import './App.css';
import Menubar from './Components/Menubar/Menubar.js'


const App = () => {
  return (
    <>
    <Menubar/>
    </>


  );
}

export default App;
