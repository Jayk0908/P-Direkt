const Aanmelden = () => {
    return (
        <>
        <div className="rectangle">
            Aanmelden
        </div>
        </>
    )
}

export default Aanmelden
